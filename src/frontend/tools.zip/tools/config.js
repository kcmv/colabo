var fs_1 = require('fs');
var yargs_1 = require('yargs');
var path_1 = require('path');
var chalk = require('chalk');
var ENVIRONMENTS = {
    DEVELOPMENT: 'dev',
    PRODUCTION: 'prod'
};
exports.SUB_PROJECT_NAME = yargs_1.argv['sub-project'] || 'KNALLEDGE';
var SUB_PROJECTS = {
    KNALLEDGE: {
        BOOTSTRAP_MODULE: 'js/app2',
        BOOTSTRAP_MODULE_HOT_LOADER: 'hot_loader_app2',
        SELECTOR: 'button-basic-usage',
        APP_SRC: 'app',
        APP_TITLE: 'KnAllEdge',
        COMPILATION: {}
    },
    BUTTONS: {
        BOOTSTRAP_MODULE: 'main',
        BOOTSTRAP_MODULE_HOT_LOADER: 'hot_loader_main',
        SELECTOR: 'button-basic-usage',
        APP_SRC: 'src/buttons',
        APP_TITLE: 'Angular 2 (with materials) - buttons',
        COMPILATION: {}
    }
};
exports.SUB_PROJECT = SUB_PROJECTS[exports.SUB_PROJECT_NAME];
console.log('__dirname: ', __dirname);
exports.PORT = yargs_1.argv['port'] || 5555;
exports.PROJECT_ROOT = path_1.normalize(path_1.join(__dirname, '..'));
exports.ENV = getEnvironment();
exports.DEBUG = yargs_1.argv['debug'] || false;
exports.DOCS_PORT = yargs_1.argv['docs-port'] || 4003;
exports.COVERAGE_PORT = yargs_1.argv['coverage-port'] || 4004;
exports.APP_BASE = yargs_1.argv['base'] || '/';
exports.ENABLE_HOT_LOADING = !!yargs_1.argv['hot-loader'];
exports.HOT_LOADER_PORT = 5578;
exports.BOOTSTRAP_MODULE = exports.ENABLE_HOT_LOADING ?
    exports.SUB_PROJECT.BOOTSTRAP_MODULE_HOT_LOADER : exports.SUB_PROJECT.BOOTSTRAP_MODULE;
exports.APP_TITLE = exports.SUB_PROJECT.APP_TITLE;
exports.APP_SRC = exports.SUB_PROJECT.APP_SRC;
exports.APP_SRC_FROM_HERE = path_1.join('..', exports.APP_SRC);
exports.ASSETS_SRC = exports.APP_SRC + "/assets";
exports.TOOLS_DIR = 'tools';
exports.DOCS_DEST = 'docs';
exports.DIST_DIR = 'dist';
exports.DEV_DEST = exports.DIST_DIR + "/dev";
exports.PROD_DEST = exports.DIST_DIR + "/prod";
exports.TMP_DIR = exports.DIST_DIR + "/tmp";
exports.APP_DEST = exports.DIST_DIR + "/" + exports.ENV;
exports.APP_DEST_FROM_HERE = path_1.join('..', exports.APP_DEST);
exports.CSS_DEST = exports.APP_DEST + "/css";
exports.FONTS_DEST = exports.APP_DEST + "/fonts";
exports.JS_DEST = exports.APP_DEST + "/js";
exports.APP_ROOT = exports.ENV === 'dev' ? "" + exports.APP_BASE + exports.APP_DEST + "/" : "" + exports.APP_BASE;
exports.VERSION = appVersion();
exports.CSS_PROD_BUNDLE = 'all.css';
exports.JS_PROD_SHIMS_BUNDLE = 'shims_bundle.js';
exports.JS_PROD_APP_BUNDLE = 'app_bundle.js';
exports.VERSION_NPM = '2.14.2';
exports.VERSION_NODE = '4.0.0';
console.log('APP_SRC: %s, APP_SRC_FROM_HERE: ', exports.APP_SRC, exports.APP_SRC_FROM_HERE);
console.log('APP_DEST: %s, APP_DEST_FROM_HERE: ', exports.APP_DEST, exports.APP_DEST_FROM_HERE);
SUB_PROJECTS.KNALLEDGE.COMPILATION = {
    INLINE_NG1: {
        SRC: [path_1.join(exports.APP_SRC, '**/*.tpl.html')]
    },
    INLINE: {
        USE_RELATIVE_PATHS: true
    },
    COMPASS: {
        GENERIC: false,
        PATHS: {
            '': { destDir: exports.APP_SRC, cssDir: 'css' },
            'components/collaboPlugins': { destDir: exports.APP_SRC, cssDir: 'css' },
            'components/halo': { destDir: exports.APP_SRC, cssDir: 'css' },
            'components/knalledgeMap': { destDir: exports.APP_SRC, cssDir: 'css' },
            'components/login': { destDir: exports.APP_SRC, cssDir: 'css' },
            'components/notify': { destDir: exports.APP_SRC, cssDir: 'css' },
            'components/ontov': { destDir: exports.APP_SRC, cssDir: 'css' },
            'components/rima': { destDir: exports.APP_SRC, cssDir: 'css' },
            'components/topiChat': { destDir: exports.APP_SRC, cssDir: 'css' }
        }
    }
};
SUB_PROJECTS.BUTTONS.COMPILATION = {
    INLINE: {
        USE_RELATIVE_PATHS: true
    },
    COMPASS: {
        GENERIC: false,
        PATHS: ['templates']
    }
};
exports.COMPASS_CONFIG = exports.SUB_PROJECT.COMPILATION.COMPASS;
console.log("SUB_PROJECT: ", exports.SUB_PROJECT);
exports.NG2LINT_RULES = customRules();
var SUB_PROJECTS_FILES = {
    KNALLEDGE: {
        APP_ASSETS: [
            { src: 'ng2-material/dist/MaterialIcons-Regular.*', asset: true, dest: exports.CSS_DEST }
        ],
        NPM_DEPENDENCIES: [
            { src: path_1.join(exports.APP_DEST, 'js/lib/debug.js'), inject: 'libs', noNorm: true },
            { src: path_1.join(exports.APP_SRC, '../bower_components/debugpp/index.js'), inject: 'libs', noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/config/config.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/config/config.env.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/interaction/interaction.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/interaction/moveAndDrag.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/interaction/keyboard.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/index.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/kNode.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/kEdge.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/kMap.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/WhoAmI.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/HowAmI.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/WhatAmI.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/vkNode.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/vkEdge.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/state.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/mapStructure.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/mapLayout.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/mapVisualization.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/mapLayoutTree.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/mapVisualizationTree.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/mapLayoutFlat.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/mapVisualizationFlat.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/mapLayoutGraph.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/mapVisualizationGraph.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/mapManager.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/knalledge/map.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/halo/js/index.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/mcm/mcm.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/mcm/mcm.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/mcm/map.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/mcm/entitiesToolset.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/collaboPlugins/js/services.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/collaboPlugins/js/directives.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/knalledgeMap/js/directives.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/knalledgeMap/js/services.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/rima/js/directives.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/rima/js/services.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/rima/js/filters.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/notify/js/directives.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/notify/js/services.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/topiChat/js/directives.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/topiChat/js/services.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/login/js/directives.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/login/js/services.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/ontov/js/vendor/underscore-1.8.3.min.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/ontov/js/vendor/backbone-1.1.2.min.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/ontov/js/vendor/query-engine.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/ontov/js/vendor/dependencies.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/ontov/js/vendor/visualsearch.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/ontov/js/services.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'components/ontov/js/directives.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'js/app.js'), inject: true, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'css/libs/bootstrap/bootstrap.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'css/libs/textAngular/textAngular.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: path_1.join(exports.APP_DEST, 'css/libs/wizard/ngWizard.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: path_1.join(exports.APP_SRC, 'css/default app.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: path_1.join(exports.APP_SRC, 'css/default.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: path_1.join(exports.APP_SRC, 'components/knalledgeMap/css/default.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: path_1.join(exports.APP_SRC, 'components/knalledgeMap/css/graph.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: path_1.join(exports.APP_SRC, 'components/halo/css/default.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: path_1.join(exports.APP_SRC, 'components/rima/css/default.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: path_1.join(exports.APP_SRC, 'components/login/css/default.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: path_1.join(exports.APP_SRC, 'components/notify/css/default.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: path_1.join(exports.APP_SRC, 'components/topiChat/css/default.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: path_1.join(exports.APP_SRC, 'components/collaboPlugins/css/default.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: path_1.join(exports.APP_SRC, 'components/ontov/css/default.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: path_1.join(exports.APP_SRC, 'components/ontov/css/visualsearch/visualsearch.css'), inject: true, dest: exports.CSS_DEST, noNorm: true },
            { src: 'ng2-material/dist/ng2-material.css', inject: true, dest: exports.CSS_DEST },
            { src: 'ng2-material/dist/font.css', inject: true, dest: exports.CSS_DEST }
        ],
        DEV_NPM_DEPENDENCIES: [],
        PROD_NPM_DEPENDENCIES: [
            { src: path_1.join(exports.TMP_DIR, 'js/ng1Templates.js'), inject: true, noNorm: true }
        ]
    },
    BUTTONS: {
        APP_ASSETS: [
            { src: 'ng2-material/dist/MaterialIcons-Regular.*', asset: true, dest: exports.CSS_DEST }
        ],
        NPM_DEPENDENCIES: [],
        DEV_NPM_DEPENDENCIES: [
            { src: 'ng2-material/dist/ng2-material.css', inject: true, dest: exports.CSS_DEST },
            { src: 'ng2-material/dist/font.css', inject: true, dest: exports.CSS_DEST }
        ],
        PROD_NPM_DEPENDENCIES: [
            { src: 'ng2-material/dist/ng2-material.css', inject: true, dest: exports.CSS_DEST },
            { src: 'ng2-material/dist/font.css', inject: true, dest: exports.CSS_DEST }
        ]
    }
};
exports.SUB_PROJECTS_FILE = SUB_PROJECTS_FILES[exports.SUB_PROJECT_NAME];
if (exports.ENABLE_HOT_LOADING) {
    console.log(chalk.bgRed.white.bold('The hot loader is temporary disabled.'));
    process.exit(0);
}
var NPM_DEPENDENCIES = [
    { src: 'systemjs/dist/system-polyfills.src.js', inject: 'shims' },
    { src: 'reflect-metadata/Reflect.js', inject: 'shims' },
    { src: 'es6-shim/es6-shim.js', inject: 'shims' },
    { src: 'systemjs/dist/system.src.js', inject: 'shims' },
    { src: 'angular2/bundles/angular2-polyfills.js', inject: 'shims' },
    { src: path_1.join(exports.APP_DEST, 'js/lib/jquery/jquery.js'), inject: 'libs', noNorm: true },
    { src: path_1.join(exports.APP_DEST, 'js/lib/bootstrap/bootstrap.js'), inject: 'libs', noNorm: true },
    { src: 'angular/angular.js', inject: 'libs' },
    { src: 'angular-route/angular-route.js', inject: 'libs' },
    { src: 'angular-sanitize/angular-sanitize.js', inject: 'libs' },
    { src: 'angular-resource/angular-resource.js', inject: 'libs' },
    { src: 'angular-animate/angular-animate.js', inject: 'libs' },
    { src: 'ngstorage/ngStorage.js', inject: 'libs' },
    { src: path_1.join(exports.APP_DEST, 'js/lib/d3/d3.js'), inject: 'libs', noNorm: true },
    { src: path_1.join(exports.APP_DEST, 'js/lib/interact-1.2.4.js'), inject: 'libs', noNorm: true },
    { src: path_1.join(exports.APP_DEST, 'js/lib/keyboard.js'), inject: 'libs', noNorm: true },
    { src: path_1.join(exports.APP_DEST, 'js/lib/tween/tween.js'), inject: 'libs', noNorm: true },
    { src: path_1.join(exports.APP_DEST, 'js/lib/socket.io/socket.io.js'), inject: 'libs', noNorm: true },
    { src: path_1.join(exports.APP_DEST, 'js/lib/ui-bootstrap/ui-bootstrap-tpls-0.12.1.js'), inject: 'libs', noNorm: true },
    { src: path_1.join(exports.APP_DEST, 'js/lib/textAngular/textAngular-rangy.min.js'), inject: 'libs', noNorm: true },
    { src: path_1.join(exports.APP_DEST, 'js/lib/textAngular/textAngular-sanitize.js'), inject: 'libs', noNorm: true },
    { src: path_1.join(exports.APP_DEST, 'js/lib/textAngular/textAngular.min.js'), inject: 'libs', noNorm: true },
    { src: path_1.join(exports.APP_DEST, 'js/lib/wizard/ngWizard.js'), inject: 'libs', noNorm: true },
    { src: path_1.join(exports.APP_DEST, 'js/lib/socket.io/angular.socket.io.js'), inject: 'libs', noNorm: true },
    { src: 'rxjs/bundles/Rx.js', inject: 'libs' },
    { src: 'angular2/bundles/angular2.js', inject: 'libs' },
    { src: 'angular2/bundles/router.js', inject: 'libs' },
    { src: 'angular2/bundles/http.js', inject: 'libs' },
];
var DEV_NPM_DEPENDENCIES = [
    { src: 'angular2/es6/dev/src/testing/shims_for_IE.js', inject: 'shims' }
];
var PROD_NPM_DEPENDENCIES = [];
exports.DEV_DEPENDENCIES = normalizeDependencies(NPM_DEPENDENCIES.
    concat(DEV_NPM_DEPENDENCIES, exports.SUB_PROJECTS_FILE.NPM_DEPENDENCIES, exports.SUB_PROJECTS_FILE.DEV_NPM_DEPENDENCIES, exports.SUB_PROJECTS_FILE.APP_ASSETS));
exports.PROD_DEPENDENCIES = normalizeDependencies(NPM_DEPENDENCIES.
    concat(PROD_NPM_DEPENDENCIES, exports.SUB_PROJECTS_FILE.NPM_DEPENDENCIES, exports.SUB_PROJECTS_FILE.PROD_NPM_DEPENDENCIES, exports.SUB_PROJECTS_FILE.APP_ASSETS));
exports.DEPENDENCIES = exports.ENV === 'dev' ? exports.DEV_DEPENDENCIES : exports.PROD_DEPENDENCIES;
var SYSTEM_CONFIG_DEV = {
    defaultJSExtensions: true,
    paths: (_a = {},
        _a[exports.BOOTSTRAP_MODULE] = "" + exports.APP_BASE + exports.BOOTSTRAP_MODULE,
        _a['angular2/*'] = exports.APP_BASE + "angular2/*",
        _a['rxjs/*'] = exports.APP_BASE + "rxjs/*",
        _a['*'] = exports.APP_BASE + "node_modules/*",
        _a
    ),
    packages: {
        angular2: { defaultExtension: false },
        rxjs: { defaultExtension: false }
    }
};
exports.SYSTEM_CONFIG = SYSTEM_CONFIG_DEV;
exports.SYSTEM_BUILDER_CONFIG = {
    defaultJSExtensions: true,
    paths: (_b = {},
        _b[exports.TMP_DIR + "/*"] = exports.TMP_DIR + "/*",
        _b['*'] = 'node_modules/*',
        _b
    )
};
function normalizeDependencies(deps) {
    deps
        .filter(function (d) { return !/\*/.test(d.src); })
        .forEach(function (d) { if (d.noNorm !== true)
        d.src = require.resolve(d.src); });
    return deps;
}
function appVersion() {
    var pkg = JSON.parse(fs_1.readFileSync('package.json').toString());
    return pkg.version;
}
function customRules() {
    var lintConf = JSON.parse(fs_1.readFileSync('tslint.json').toString());
    return lintConf.rulesDirectory;
}
function getEnvironment() {
    var base = yargs_1.argv['_'];
    var prodKeyword = !!base.filter(function (o) { return o.indexOf(ENVIRONMENTS.PRODUCTION) >= 0; }).pop();
    if (base && prodKeyword || yargs_1.argv['env'] === ENVIRONMENTS.PRODUCTION) {
        return ENVIRONMENTS.PRODUCTION;
    }
    else {
        return ENVIRONMENTS.DEVELOPMENT;
    }
}
var _a, _b;
//# sourceMappingURL=config.js.map