var CONFIG = require('../config');
function templateLocals() {
    return CONFIG;
}
exports.templateLocals = templateLocals;
//# sourceMappingURL=template_locals.js.map