var merge = require('merge-stream');
var path_1 = require('path');
var config_1 = require('../config');
module.exports = function buildAssetsProd(gulp, plugins) {
    return function () {
        return merge(copyProjectInternalAsets(), copyProjectExternalAsets());
        function copyProjectExternalAsets() {
            var externalAssetFiles = config_1.PROD_DEPENDENCIES.filter(function (d) { return d.asset; });
            var tasks = externalAssetFiles.map(function (element) {
                return gulp.src(element.src)
                    .pipe(gulp.dest(element.dest));
            });
            return merge.apply(void 0, tasks);
        }
        function copyProjectInternalAsets() {
            var es = require('event-stream');
            var onlyDirs = function (es) {
                return es.map(function (file, cb) {
                    if (file.stat.isFile()) {
                        return cb(null, file);
                    }
                    else {
                        return cb();
                    }
                });
            };
            return gulp.src([
                path_1.join(config_1.APP_SRC, '**'),
                '!' + path_1.join(config_1.APP_SRC, '**', '*.ts'),
                '!' + path_1.join(config_1.APP_SRC, '**', '*.css'),
                '!' + path_1.join(config_1.APP_SRC, '**', '*.html'),
                '!' + path_1.join(config_1.ASSETS_SRC, '**', '*.js')
            ])
                .pipe(onlyDirs(es))
                .pipe(gulp.dest(config_1.APP_DEST));
        }
    };
};
//# sourceMappingURL=build.assets.prod.js.map