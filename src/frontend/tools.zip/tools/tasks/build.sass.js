var path_1 = require('path');
var config_1 = require('../config');
module.exports = function buildCss(gulp, plugins) {
    var notifyInfo = {
        title: 'Gulp',
        icon: require.resolve('gulp-notify/assets/gulp-error.png')
    };
    var plumberErrorHandler = { errorHandler: plugins.notify.onError({
            title: notifyInfo.title,
            icon: notifyInfo.icon,
            message: 'Error: <%= error.message %>'
        })
    };
    return function () {
        var src = [
            path_1.join(config_1.APP_SRC, '**/sass/*.scss')
        ];
        return gulp.src(src)
            .pipe(plugins.plumber(plumberErrorHandler))
            .pipe(plugins.sass())
            .pipe(gulp.dest(config_1.APP_SRC));
    };
};
//# sourceMappingURL=build.sass.js.map