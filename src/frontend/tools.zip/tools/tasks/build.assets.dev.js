var merge = require('merge-stream');
var path_1 = require('path');
var config_1 = require('../config');
module.exports = function buildAssetsDev(gulp, plugins) {
    return function () {
        return merge(copyProjectInternalAsets(), copyProjectExternalAsets());
        function copyProjectExternalAsets() {
            var externalAssetFiles = config_1.DEV_DEPENDENCIES.filter(function (d) { return d.asset; });
            var tasks = externalAssetFiles.map(function (element) {
                return gulp.src(element.src)
                    .pipe(gulp.dest(element.dest));
            });
            return merge.apply(void 0, tasks);
        }
        function copyProjectInternalAsets() {
            var stream = gulp.src([
                path_1.join(config_1.APP_SRC, '**'),
                '!' + path_1.join(config_1.APP_SRC, '**', '*.ts'),
                '!' + path_1.join(config_1.APP_SRC, '**', '*.scss')
            ])
                .pipe(plugins.sniff("internal-assets", { captureFolders: true, captureFilenames: false }))
                .pipe(gulp.dest(config_1.APP_DEST));
            stream.on('end', function () {
                console.log("[build.assets.dev] internal-assets:", plugins.sniff.get("internal-assets"));
            });
            return stream;
        }
    };
};
//# sourceMappingURL=build.assets.dev.js.map