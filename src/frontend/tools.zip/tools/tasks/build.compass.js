var merge = require('merge-stream');
var path_1 = require('path');
var config_1 = require('../config');
module.exports = function buildCss(gulp, plugins) {
    return function () {
        var notifyInfo = {
            title: 'Gulp',
            icon: require.resolve('gulp-notify/assets/gulp-error.png')
        };
        var plumberErrorHandler = {
            errorHandler: plugins.notify.onError({
                title: notifyInfo.title,
                icon: notifyInfo.icon,
                message: 'Error: <%= error.message %>'
            })
        };
        console.log('__dirname: ', __dirname);
        console.log('COMPASS_CONFIG.GENERIC: ', config_1.COMPASS_CONFIG.GENERIC);
        var compassTask = function (scssFiles, distPathCss, projectPath) {
            console.log('[compassTask] projectPath: ', projectPath);
            console.log('[compassTask] scssFiles: ', scssFiles);
            console.log('[compassTask] distPathCss: ', distPathCss);
            var task = gulp.src(scssFiles)
                .pipe(plugins.plumber(plumberErrorHandler))
                .pipe(plugins.compass({
                outputStyle: 'nested',
                environment: 'development',
                noLineComments: true,
                require: ['susy', 'breakpoint'],
                trace: true,
                style: 'nested',
                relative: true,
                sourcemap: true,
                css: distPathCss,
                sass: projectPath,
                task: 'compile'
            }))
                .pipe(gulp.dest(distPathCss));
            return task;
        };
        var appPath;
        var projectPath;
        var distPath;
        var distPathCss;
        var scssFiles;
        if (config_1.COMPASS_CONFIG.GENERIC) {
            appPath = config_1.APP_SRC;
            projectPath = path_1.join(__dirname, '../..', appPath);
            distPath = config_1.APP_DEST;
            distPathCss = path_1.join(distPath, '');
            scssFiles = path_1.join(appPath, '**/sass/*.scss');
            var task = compassTask(scssFiles, distPathCss, projectPath);
            return task;
        }
        else {
            var tasks = Object.keys(config_1.COMPASS_CONFIG.PATHS).map(function (path) {
                var pathVal = config_1.COMPASS_CONFIG.PATHS[path];
                var cssDir = '';
                var destDir = config_1.APP_DEST;
                if (typeof pathVal === 'object') {
                    if ('cssDir' in pathVal)
                        cssDir = pathVal.cssDir;
                    if ('destDir' in pathVal)
                        destDir = pathVal.destDir;
                }
                appPath = path_1.join(config_1.APP_SRC, path);
                projectPath = path_1.join(__dirname, '../..', appPath, 'sass');
                distPath = path_1.join(destDir, path);
                distPathCss = path_1.join(distPath, cssDir);
                scssFiles = ['*.scss'];
                var task = compassTask(scssFiles, distPathCss, projectPath);
                return task;
            });
            return merge.apply(void 0, tasks);
        }
    };
};
//# sourceMappingURL=build.compass.js.map