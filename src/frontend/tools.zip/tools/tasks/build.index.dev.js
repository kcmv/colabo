var path_1 = require('path');
var config_1 = require('../config');
var utils_1 = require('../utils');
module.exports = function buildIndexDev(gulp, plugins) {
    var dateTime = '?' + Date.now();
    console.log("[build.index.dev] process.cwd(): ", process.cwd());
    return function () {
        var stream = gulp.src(path_1.join(config_1.APP_DEST, 'index.html'))
            .pipe(inject('shims'))
            .pipe(inject('libs'))
            .pipe(inject())
            .pipe(plugins.template(utils_1.templateLocals()))
            .pipe(gulp.dest(config_1.APP_DEST));
        stream.on('end', function () {
            console.log("[build.index.dev] injected:", plugins.sniff.get("injected"));
        });
        return stream;
    };
    function inject(name) {
        var nameInner = name || 'default';
        var sourceStream = gulp.src(getInjectablesDependenciesRef(name), { read: false })
            .pipe(plugins.sniff(nameInner, { captureFolders: true, captureFilenames: true }));
        sourceStream.on('end', function () {
            console.log("[build.index.dev] (name:%s): ", nameInner, plugins.sniff.get(nameInner));
        });
        return plugins.inject(sourceStream, {
            name: name,
            relative: true,
            addRootSlash: false,
            addSuffix: dateTime
        });
    }
    function getInjectablesDependenciesRef(name) {
        name = name || true;
        var dependencies = config_1.DEV_DEPENDENCIES
            .filter(function (dep) { return dep['inject'] && dep['inject'] === name; })
            .map(mapPath);
        console.log("[getInjectablesDependenciesRef] dependencies['%s']: ", name, dependencies);
        return dependencies;
    }
    function mapPath(dep) {
        var envPath = dep.src;
        if (envPath.startsWith(config_1.APP_SRC)) {
            envPath = path_1.join(config_1.APP_DEST, dep.src.replace(config_1.APP_SRC, ''));
        }
        return envPath;
    }
};
//# sourceMappingURL=build.index.dev.js.map