var path_1 = require('path');
var merge = require('merge-stream');
var config_1 = require('../config');
var utils_1 = require('../utils');
module.exports = function buildJSProd(gulp, plugins) {
    return function () {
        return merge(inlineNg1Templates(), inlineNg2TemplatesAndCompileTs());
        function inlineNg1Templates() {
            var INLINE_OPTIONS = {};
            var src = config_1.SUB_PROJECT.COMPILATION.INLINE_NG1.SRC || [
                path_1.join(config_1.APP_SRC, '**/*.html'),
                '!' + path_1.join(config_1.APP_SRC, '**/index.html')
            ];
            var stream = gulp.src(src)
                .pipe(plugins.plumber())
                .pipe(plugins.sniff('inlineNg1Templates'))
                .pipe(plugins.angularTemplatecache('js/ng1Templates.js', INLINE_OPTIONS));
            stream.on('end', function () {
                console.log("[build.js.prod] inlineNg1Templates:", plugins.sniff.get("inlineNg1Templates"));
            });
            return stream
                .pipe(plugins.template(utils_1.templateLocals()))
                .pipe(gulp.dest(config_1.TMP_DIR));
        }
        function inlineNg2TemplatesAndCompileTs() {
            var INLINE_OPTIONS = {
                base: config_1.TMP_DIR,
                indent: 4,
                useRelativePaths: config_1.SUB_PROJECT.COMPILATION.INLINE.USE_RELATIVE_PATHS,
                removeLineBreaks: true
            };
            var tsProject = utils_1.tsProjectFn(plugins);
            var src = [
                'typings/browser.d.ts',
                'tools/manual_typings/**/*.d.ts',
                path_1.join(config_1.APP_SRC, '**/*.ts'),
                '!' + path_1.join(config_1.APP_SRC, '**/*.spec.ts'),
                '!' + path_1.join(config_1.APP_SRC, '**/*.e2e.ts')
            ];
            var result = gulp.src(src)
                .pipe(plugins.plumber())
                .pipe(plugins.inlineNg2Template(INLINE_OPTIONS))
                .pipe(plugins.typescript(tsProject));
            return result.js
                .pipe(plugins.template(utils_1.templateLocals()))
                .pipe(gulp.dest(config_1.TMP_DIR));
        }
    };
};
//# sourceMappingURL=build.js.prod.js.map